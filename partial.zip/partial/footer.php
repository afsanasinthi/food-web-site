 <!-- footer start -->
 <div class="footer">
        <div class="wrapper">
        <div class="copy_right">
                <p>Copyright &copy; All right resorved by <span>GOOD FOOD</span></p>
            </div>
               

            </div>
        </div>
        <!-- footer end -->
        